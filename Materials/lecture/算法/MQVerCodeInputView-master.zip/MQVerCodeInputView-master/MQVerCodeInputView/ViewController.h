//
//  ViewController.h
//  MQVerCodeInputView
//
//  Created by  林美齐 on 16/12/6.
//  Copyright © 2016年  林美齐. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

